function validateForm() {
    var userid = document.getElementById('userid').value;
    var password = document.getElementById('password').value;
    var name = document.getElementById('name').value;
    var country = document.getElementById('country').value;
    var zip = document.getElementById('zip').value;
    var email = document.getElementById('email').value;
    var sex = document.querySelector('input[name="sex"]:checked');
    var language = document.querySelector('input[name="language"]:checked');

    if (userid.length < 5 || userid.length > 12)
        {
        alert("User id must be of length 5 to 12.");
        return false;
    }

    if (password.length < 7 || password.length > 12) 
        {
        alert("Password must be of length 7 to 12.");
        return false;
    }

    if (!/^[a-zA-Z]+$/.test(name)) 
        
        {
        alert("Required and alphabets only");
        return false;
    }

    if (country === "") 
        {
        alert("Must select a country.");
        return false;
    }

    if (!/^\d+$/.test(zip)) 
        {
        alert("Must be numeric only.");
        return false;
    }

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) 
        {
        alert("Must be a valid email.");
        return false;
    }

    if (!sex) 
        {
        alert("Sex is required.");
        return false;
    }

    if (!language) 
        {
        alert("Language is required.");
        return false;
    }

    return true;
}